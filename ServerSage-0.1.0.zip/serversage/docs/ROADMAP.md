# ServerSage roadmap

This roadmap is a product plan, not a claim that these capabilities already exist.

## 0.1 — Foundation (current)
- [x] Resource metrics from Linux procfs and standard library.
- [x] CPU, memory and disk health heuristics.
- [x] Basic SSH configuration review.
- [x] Selected cron/systemd persistence permission checks.
- [x] Heuristic web-shell indicator scan.
- [x] SSH authorized-keys inventory signal.
- [x] JSON output, CLI, tests and CI.

## 0.2 — Deeper host inventory
- [ ] Process inventory with parent/child relationships, executable path, user, start time and deleted-executable indicators.
- [ ] Listening sockets and port-to-process mapping (ss/netlink integration).
- [ ] User, sudoers and group membership drift checks.
- [ ] Systemd unit inventory, timers, enabled services and override drop-ins.
- [ ] Package manager inventory and verification (dpkg/rpm verification where supported).
- [ ] File integrity baseline with explicit user-approved baseline creation.
- [ ] Kernel module inventory and known rootkit indicator checks; clearly document limitations.

## 0.3 — Hosting and container diagnostics
- [ ] Docker daemon/container inventory, image age, privileged mode, host mounts, exposed ports and restart policies.
- [ ] cPanel/WHM version, service status, account and configuration health checks when paths/commands are present.
- [ ] Apache/Nginx, PHP-FPM, MariaDB/MySQL and mail queue diagnostics.
- [ ] Multi-PHP and common hosting permission/configuration checks.
- [ ] Provider-aware checks that never assume a particular hosting layout.

## 0.4 — Better security signal
- [ ] YARA integration as an optional dependency with user-supplied rules.
- [ ] ClamAV integration when installed; report engine/signature age and scan errors.
- [ ] Web directory baseline and diff mode.
- [ ] Suspicious outbound connection and DNS configuration indicators.
- [ ] Authentication log summary and brute-force signal detection.
- [ ] CVE/package advisory correlation using an offline or explicitly enabled data source.
- [ ] SARIF and HTML reports; evidence redaction controls.

## 1.0 — Operational product
- [ ] Plugin interface and documented check API.
- [ ] Signed releases, SBOM, provenance and reproducible build process.
- [ ] Cross-distro integration test matrix (Ubuntu, Debian, AlmaLinux).
- [ ] Performance benchmarks and large-host scan limits.
- [ ] Stable finding IDs, severity rubric, confidence levels and suppressions.
- [ ] Documentation reviewed by external Linux administrators.

## Design constraints
- Read-only by default; remediation is a separate opt-in proposal workflow, never silent mutation.
- Do not run discovered files or scripts.
- Avoid destructive responses and preserve forensic evidence.
- Report evidence and confidence, distinguish absence of evidence from evidence of absence.
