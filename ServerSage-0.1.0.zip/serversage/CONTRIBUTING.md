# Contributing

Thanks for helping improve ServerSage.

1. Open an issue describing the operational problem and affected distributions.
2. Keep checks read-only and bounded; do not execute discovered files.
3. Add unit tests, especially for false-positive cases and permission-denied paths.
4. Do not include live hostnames, IPs, usernames, keys, logs or customer data in test fixtures.
5. Run `pytest` and `python -m compileall -q serversage` before opening a PR.
6. Explain any new filesystem traversal, subprocess call, privilege assumption or network access in the PR.

Security vulnerabilities should be reported privately; see `SECURITY.md`.
