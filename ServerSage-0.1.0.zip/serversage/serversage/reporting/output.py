from __future__ import annotations
import json
from pathlib import Path
from serversage.models import AuditReport


def to_json(report: AuditReport) -> str:
    return json.dumps(report.to_dict(), indent=2, sort_keys=True)


def write_json(report: AuditReport, path: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(to_json(report) + "\n", encoding="utf-8")
