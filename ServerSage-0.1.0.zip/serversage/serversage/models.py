from __future__ import annotations
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

@dataclass
class Finding:
    id: str
    title: str
    severity: str
    category: str
    summary: str
    evidence: dict[str, Any] = field(default_factory=dict)
    recommendation: str = ""
    confidence: str = "medium"

@dataclass
class AuditReport:
    host: str
    platform: str
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metrics: dict[str, Any] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
