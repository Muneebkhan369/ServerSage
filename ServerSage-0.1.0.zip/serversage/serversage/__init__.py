"""ServerSage: read-only Linux diagnostics and security auditing."""
__version__ = "0.1.0"
