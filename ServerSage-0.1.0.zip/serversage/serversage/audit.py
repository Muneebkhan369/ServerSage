from __future__ import annotations
import platform, socket
from serversage.models import AuditReport
from serversage.collectors.system import collect_system
from serversage.checks.health import health_findings
from serversage.checks.security import security_findings
from serversage.checks.config import config_findings


def run_audit(include_security: bool = True) -> AuditReport:
    metrics = collect_system()
    report = AuditReport(host=socket.gethostname(), platform=platform.platform(), metrics=metrics)
    report.findings.extend(health_findings(metrics))
    report.findings.extend(config_findings())
    if include_security:
        try:
            report.findings.extend(security_findings())
        except Exception as exc:  # Keep partial reports useful; never hide scan errors.
            report.errors.append(f"Security checks partially failed: {type(exc).__name__}: {exc}")
    report.metadata = {"scanner": "ServerSage", "mode": "read-only", "security_checks_enabled": include_security}
    return report
