from __future__ import annotations
import argparse, json, sys
from serversage import __version__
from serversage.audit import run_audit
from serversage.reporting.output import to_json, write_json


def main() -> int:
    parser = argparse.ArgumentParser(prog="serversage", description="Read-only Linux health and security indicator audit")
    parser.add_argument("--version", action="version", version=f"ServerSage {__version__}")
    parser.add_argument("--json", dest="json_path", help="Write the complete report to this JSON file (also prints to stdout)")
    parser.add_argument("--no-security", action="store_true", help="Skip filesystem security indicator checks")
    parser.add_argument("--summary", action="store_true", help="Print a compact human-readable summary instead of JSON")
    args = parser.parse_args()
    report = run_audit(include_security=not args.no_security)
    if args.json_path:
        write_json(report, args.json_path)
    if args.summary:
        counts = {level: sum(1 for f in report.findings if f.severity == level) for level in ("critical", "high", "medium", "low", "info")}
        print(f"ServerSage {__version__} | {report.host} | {report.platform}")
        print(f"Findings: {len(report.findings)} | " + " ".join(f"{k}={v}" for k, v in counts.items()))
        for finding in report.findings:
            print(f"[{finding.severity.upper()}] {finding.title} — {finding.summary}")
        if report.errors:
            print("Errors:", *report.errors, sep="\n- ", file=sys.stderr)
    else:
        print(to_json(report))
    return 0 if not any(f.severity in {"critical", "high"} for f in report.findings) else 2

if __name__ == "__main__":
    raise SystemExit(main())
