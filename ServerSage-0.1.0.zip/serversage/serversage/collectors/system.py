from __future__ import annotations
import os, platform, shutil, socket, time
from pathlib import Path
from typing import Any


def _read_text(path: str) -> str | None:
    try:
        return Path(path).read_text(errors="replace")
    except (OSError, PermissionError):
        return None


def collect_system() -> dict[str, Any]:
    mem: dict[str, int] = {}
    raw = _read_text("/proc/meminfo") or ""
    for line in raw.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            parts = value.strip().split()
            if parts and parts[0].isdigit():
                mem[key] = int(parts[0]) * (1024 if len(parts) > 1 and parts[1].lower() == "kb" else 1)
    cpu_count = os.cpu_count() or 1
    load = None
    try:
        load = list(os.getloadavg())
    except (AttributeError, OSError):
        pass
    usage = shutil.disk_usage("/")
    try:
        uptime = float((_read_text("/proc/uptime") or "0").split()[0])
    except (ValueError, IndexError):
        uptime = None
    net = {}
    net_text = _read_text("/proc/net/dev") or ""
    for line in net_text.splitlines()[2:]:
        if ":" not in line:
            continue
        iface, vals = line.split(":", 1)
        nums = vals.split()
        if len(nums) >= 9:
            try:
                net[iface.strip()] = {"rx_bytes": int(nums[0]), "rx_packets": int(nums[1]), "tx_bytes": int(nums[8]), "tx_packets": int(nums[9])}
            except (ValueError, IndexError):
                continue
    return {
        "hostname": socket.gethostname(), "platform": platform.platform(),
        "os": platform.system(), "os_release": platform.release(),
        "architecture": platform.machine(), "python": platform.python_version(),
        "cpu_count": cpu_count, "load_average": load,
        "memory_bytes": {"total": mem.get("MemTotal"), "available": mem.get("MemAvailable"), "free": mem.get("MemFree"), "swap_total": mem.get("SwapTotal"), "swap_free": mem.get("SwapFree")},
        "root_disk_bytes": {"total": usage.total, "used": usage.used, "free": usage.free},
        "uptime_seconds": uptime, "network_interfaces": net,
    }
