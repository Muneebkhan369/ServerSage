from __future__ import annotations
import os, shutil
from pathlib import Path
from serversage.models import Finding


def config_findings() -> list[Finding]:
    out: list[Finding] = []
    sshd = Path("/etc/ssh/sshd_config")
    try:
        text = sshd.read_text(errors="ignore")
        values = {}
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) == 2:
                values[parts[0].lower()] = parts[1].strip()
        if values.get("permitrootlogin", "").lower() in {"yes", "without-password", "prohibit-password"}:
            out.append(Finding("CFG-SSH-ROOT-001", "SSH root login is enabled or key-only", "medium", "configuration", "sshd_config permits direct root login.", {"permitrootlogin": values.get("permitrootlogin")}, "Prefer PermitRootLogin no and use named sudo-enabled accounts after validating recovery access."))
        if values.get("passwordauthentication", "").lower() == "yes":
            out.append(Finding("CFG-SSH-PASSWORD-001", "SSH password authentication is enabled", "low", "configuration", "Password authentication increases exposure to credential guessing when SSH is internet reachable.", {"passwordauthentication": "yes"}, "Consider key-based authentication plus MFA or an access gateway, while retaining a tested recovery route."))
    except (OSError, PermissionError):
        pass
    for tool in ("ufw", "firewall-cmd", "nft", "iptables"):
        if shutil.which(tool):
            out.append(Finding("CFG-FIREWALL-TOOL-001", "Firewall management tool detected", "info", "configuration", "A firewall management utility is installed; this does not confirm that filtering is active.", {"tool": tool}, "Check the active ruleset and externally reachable ports."))
            break
    if os.geteuid() != 0:
        out.append(Finding("OPS-PERM-001", "Running without root privileges", "info", "coverage", "Some system and security checks may be incomplete because the process is unprivileged.", {}, "Run with sudo only when you understand the read-only checks and trust the installed source."))
    return out
