from __future__ import annotations
from typing import Any
from serversage.models import Finding


def health_findings(metrics: dict[str, Any]) -> list[Finding]:
    out: list[Finding] = []
    cpu = max(1, int(metrics.get("cpu_count") or 1))
    loads = metrics.get("load_average")
    if loads and loads[0] > cpu * 1.5:
        out.append(Finding("HEALTH-CPU-001", "High system load", "medium", "performance", "1-minute load average is materially above the available CPU count.", {"load_1m": loads[0], "cpu_count": cpu}, "Inspect top processes, I/O wait and recent workload changes before resizing or terminating anything."))
    memory = metrics.get("memory_bytes", {})
    total, available = memory.get("total"), memory.get("available")
    if total and available is not None:
        pct = 100 * (total - available) / total
        if pct >= 92:
            sev = "high" if pct >= 97 else "medium"
            out.append(Finding("HEALTH-MEM-001", "Very high memory pressure", sev, "performance", "Available memory is low relative to total RAM.", {"used_percent_estimate": round(pct, 1), "available_bytes": available}, "Identify memory-heavy processes and check for leaks; avoid killing services automatically."))
    disk = metrics.get("root_disk_bytes", {})
    if disk.get("total"):
        pct = 100 * disk["used"] / disk["total"]
        if pct >= 90:
            out.append(Finding("HEALTH-DISK-001", "Root filesystem nearly full", "high" if pct >= 97 else "medium", "storage", "Root filesystem usage has crossed the warning threshold.", {"used_percent": round(pct, 1), "free_bytes": disk["free"]}, "Use du/find to identify large paths; preserve logs and backups until retention policy is confirmed."))
    return out
