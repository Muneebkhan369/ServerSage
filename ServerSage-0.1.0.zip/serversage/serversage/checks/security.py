from __future__ import annotations
import os, re, stat
from pathlib import Path
from typing import Any, Iterable
from serversage.models import Finding

# Heuristic paths only: presence is an indicator, not proof of compromise.
PERSISTENCE_PATHS = [
    Path("/etc/cron.d"), Path("/etc/cron.hourly"), Path("/etc/cron.daily"),
    Path("/etc/cron.weekly"), Path("/etc/cron.monthly"), Path("/var/spool/cron"),
    Path("/etc/systemd/system"), Path("/usr/local/lib/systemd/system"),
]
WEB_ROOTS = [Path("/var/www"), Path("/srv/www"), Path("/usr/share/nginx/html")]
SUSPICIOUS_NAME = re.compile(r"(wp-vcd|wso|c99|r57|b374k|mini.?shell|shell\.php|cmd\.php|alfa.?shell)", re.I)
SUSPICIOUS_CODE = re.compile(r"(base64_decode\s*\(|eval\s*\(|shell_exec\s*\(|passthru\s*\(|system\s*\(|proc_open\s*\(|assert\s*\()", re.I)


def _safe_entries(path: Path) -> Iterable[Path]:
    try:
        yield from list(path.iterdir())[:500]
    except (OSError, PermissionError):
        return


def scan_persistence() -> list[Finding]:
    findings: list[Finding] = []
    for root in PERSISTENCE_PATHS:
        if not root.exists() or not root.is_dir():
            continue
        for item in _safe_entries(root):
            try:
                st = item.lstat()
                if stat.S_ISLNK(st.st_mode) and str(item.resolve()).startswith(("/tmp/", "/var/tmp/", "/dev/shm/")):
                    findings.append(Finding("SEC-PERSIST-001", "Persistence entry points to a temporary location", "high", "persistence", "A cron/systemd entry is a symlink into a commonly abused temporary directory.", {"path": str(item), "target": os.readlink(item)}, "Verify the owning package and change history. Preserve evidence before disabling it.", "medium"))
                if item.is_file() and os.access(item, os.X_OK) and (item.stat().st_mode & stat.S_IWOTH):
                    findings.append(Finding("SEC-PERSIST-002", "World-writable executable persistence entry", "high", "persistence", "An executable file in a persistence directory is writable by all local users.", {"path": str(item), "mode": oct(stat.S_IMODE(st.st_mode))}, "Check ownership, package provenance and timestamps; restrict permissions only after validation.", "medium"))
            except OSError:
                continue
    return findings


def scan_webshell_indicators(roots: list[Path] | None = None, max_files: int = 3000, max_bytes: int = 512_000) -> list[Finding]:
    findings: list[Finding] = []
    scanned = 0
    for root in roots or WEB_ROOTS:
        if not root.exists() or not root.is_dir():
            continue
        for base, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "vendor", "cache"}]
            for name in files:
                path = Path(base) / name
                if scanned >= max_files:
                    return findings
                if path.is_symlink() or path.suffix.lower() not in {".php", ".phtml", ".php5", ".inc", ".jsp", ".aspx", ".py"}:
                    continue
                scanned += 1
                try:
                    if path.stat().st_size > max_bytes:
                        continue
                    content = path.read_text(errors="ignore")
                    name_hit = bool(SUSPICIOUS_NAME.search(name))
                    code_hits = sorted(set(m.group(0) for m in SUSPICIOUS_CODE.finditer(content)))
                    # Require multiple indicators to reduce noisy results.
                    if name_hit or len(code_hits) >= 2:
                        findings.append(Finding("SEC-WEBSHELL-001", "Possible web-shell or obfuscated execution pattern", "high" if name_hit else "medium", "webshell", "A web-accessible script matches heuristic indicators commonly seen in unauthorized command execution or obfuscation.", {"path": str(path), "suspicious_filename": name_hit, "matched_functions": code_hits[:8]}, "Review the complete file, owner, mtime, deployment history and access logs. Compare with a trusted release; do not execute the file.", "low" if not name_hit else "medium"))
                except (OSError, PermissionError):
                    continue
    return findings


def scan_ssh_authorized_keys() -> list[Finding]:
    findings: list[Finding] = []
    home = Path("/home")
    users = [Path("/root")] + [p for p in _safe_entries(home) if p.is_dir()]
    for user_dir in users:
        keyfile = user_dir / ".ssh" / "authorized_keys"
        try:
            if not keyfile.is_file():
                continue
            lines = [line.strip() for line in keyfile.read_text(errors="ignore").splitlines() if line.strip() and not line.lstrip().startswith("#")]
            if lines:
                findings.append(Finding("SEC-SSH-KEYS-001", "SSH authorized keys need ownership review", "info", "access", "Authorized SSH keys are configured; ServerSage cannot determine whether each key is approved.", {"file": str(keyfile), "key_count": len(lines), "key_types": sorted({line.split()[0] for line in lines if line.startswith(("ssh-", "ecdsa-", "sk-"))})}, "Verify every key fingerprint and owner against your access inventory; remove unknown keys only after confirming out-of-band access."))
        except (OSError, PermissionError):
            continue
    return findings


def security_findings() -> list[Finding]:
    return scan_persistence() + scan_webshell_indicators() + scan_ssh_authorized_keys()
