from serversage.cli import main
raise SystemExit(main())
