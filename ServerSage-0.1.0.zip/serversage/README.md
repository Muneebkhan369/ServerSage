# ServerSage

**Open-source Linux server health, configuration and compromise-indicator auditing.**

ServerSage is a read-only command-line toolkit for Linux administrators, VPS providers and hosting teams. It collects host resource metrics, highlights common operational risks, and checks selected persistence and web-shell indicators. It is designed to be understandable, auditable and safe by default.

> **Important:** ServerSage is an early development release (0.1.0), not an EDR, antivirus product, rootkit detector or incident-response replacement. Heuristic findings can be false positives and a clean report does not prove a system is uncompromised. Test in a lab before using it on production systems.

## Current capabilities

- CPU count and load average, memory/swap, root filesystem, uptime and network interface counters.
- Health thresholds for sustained CPU load, low available RAM and low disk space.
- SSH configuration checks for root login and password authentication.
- Read-only inspection of cron and systemd persistence directories for selected risky permissions and temporary-path symlinks.
- Heuristic web-shell indicators in common web roots (`/var/www`, `/srv/www`, `/usr/share/nginx/html`). It checks suspicious filenames and combinations of dynamic execution/obfuscation functions; it does not execute scanned content.
- Inventory signal for SSH `authorized_keys`; key trust must be verified by an administrator.
- Structured JSON output, human summary, tests and GitHub Actions CI.

## Supported platforms

Designed for Linux with Python 3.10+. Ubuntu, Debian and AlmaLinux are intended targets. cPanel/WHM and Docker-specific inspection are planned modules, not yet implemented in this initial source drop. See `docs/ROADMAP.md`.

## Install

```bash
git clone https://github.com/Muneebkhan369/ServerSage.git
cd ServerSage
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -e '.[test]'
```

Run without elevated permissions first:

```bash
serversage --summary
serversage --json report.json
python -m serversage --summary
```

Some checks may be incomplete without root. Only run with `sudo` after reviewing the source and accepting the privacy implications:

```bash
sudo serversage --summary --json /root/serversage-report.json
```

Exit code is `2` when one or more high/critical findings are present, otherwise `0`. The tool does not automatically remediate findings.

## Example output

```text
ServerSage 0.1.0 | example-host | Linux-...
Findings: 2 | critical=0 high=1 medium=1 low=0 info=0
[HIGH] Root filesystem nearly full — Root filesystem usage has crossed the warning threshold.
[MEDIUM] High system load — 1-minute load average is materially above the available CPU count.
```

Exact findings depend on the host.

## Security model and privacy

ServerSage runs local checks and does not send telemetry, upload data, or make outbound network requests. JSON reports may contain hostnames, file paths, interface names and security configuration details; store and share them as sensitive data. See [SECURITY.md](SECURITY.md).

The scanner is read-only: no automatic deletion, quarantine, killing processes, firewall changes, account changes, SSH changes, service restarts or package installation. Review every finding manually and preserve forensic evidence before making changes.

## Development

```bash
pip install -e '.[test]'
pytest
python -m compileall -q serversage
```

Contributions should include tests, explain false-positive trade-offs, and keep the default behavior read-only. Please avoid uploading real server reports or secrets to public issues.

## License

Apache-2.0. See [LICENSE](LICENSE).
