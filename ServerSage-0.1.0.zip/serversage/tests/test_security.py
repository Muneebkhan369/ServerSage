from pathlib import Path
from serversage.checks.security import scan_webshell_indicators


def test_webshell_heuristic_flags_multi_indicator_script(tmp_path: Path):
    web = tmp_path / "web"
    web.mkdir()
    target = web / "upload.php"
    target.write_text("<?php $x = base64_decode($_GET['x']); eval($x); ?>")
    findings = scan_webshell_indicators([web])
    assert len(findings) == 1
    assert findings[0].category == "webshell"
    assert findings[0].evidence["path"] == str(target)


def test_webshell_heuristic_does_not_flag_normal_file(tmp_path: Path):
    web = tmp_path / "web"
    web.mkdir()
    (web / "index.php").write_text("<?php echo 'Hello'; ?>")
    assert scan_webshell_indicators([web]) == []
