from serversage.checks.health import health_findings


def test_health_thresholds_emit_expected_findings():
    metrics = {
        "cpu_count": 2,
        "load_average": [5.0, 3.0, 2.0],
        "memory_bytes": {"total": 1000, "available": 20},
        "root_disk_bytes": {"total": 1000, "used": 950, "free": 50},
    }
    ids = {finding.id for finding in health_findings(metrics)}
    assert {"HEALTH-CPU-001", "HEALTH-MEM-001", "HEALTH-DISK-001"} <= ids


def test_healthy_host_has_no_health_findings():
    metrics = {
        "cpu_count": 8,
        "load_average": [1.0, 0.5, 0.4],
        "memory_bytes": {"total": 1000, "available": 700},
        "root_disk_bytes": {"total": 1000, "used": 400, "free": 600},
    }
    assert health_findings(metrics) == []
