import json
from serversage.models import AuditReport, Finding
from serversage.reporting.output import to_json


def test_report_serializes_to_json():
    report = AuditReport(host="test", platform="linux", findings=[Finding("X", "Demo", "info", "test", "Example")])
    data = json.loads(to_json(report))
    assert data["host"] == "test"
    assert data["findings"][0]["id"] == "X"
