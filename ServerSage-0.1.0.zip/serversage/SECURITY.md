# Security policy

## Scope

ServerSage is a defensive, read-only auditing tool. It reports configuration weaknesses and suspicious indicators; it is not a forensic guarantee and cannot prove a system is clean.

## Reporting vulnerabilities

Please do not publish exploitable details in public issues. Contact the maintainer privately through GitHub's repository security advisory feature once the project repository is published. Include affected version, reproduction steps, impact, and relevant sanitized logs.

## Safe operation

- The scanner does not delete files, kill processes, disable accounts, edit firewall rules, change SSH settings, or modify services.
- A finding is an indicator requiring human validation, not a verdict of compromise.
- Run only on systems you own or are explicitly authorized to administer.
- Reports may contain hostnames, usernames, paths and interface details. Treat generated reports as sensitive operational data.
